package com.example.epimahkovdenis_pr31_v1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class CreditCalActivity : AppCompatActivity() {

    private lateinit var seekBar:SeekBar
    private lateinit var imageBack: ImageView
    private lateinit var calculation: Button
    private lateinit var loanTerm: EditText
    private lateinit var currentValueText: TextView

    private var currentAmount: Int = 30000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_credit_cal)
        seekBar = findViewById(R.id.seekBar)
        imageBack = findViewById(R.id.arrow_credit)
        calculation = findViewById(R.id.button_calculate)
        loanTerm = findViewById(R.id.loan_term)
        currentValueText = findViewById(R.id.current_amount_bar)


        val currentValueText = findViewById<TextView>(R.id.current_amount_bar)
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val currentAmount = progress + 30000
                currentValueText.text = currentAmount.toString()
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }
        })


        imageBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        calculation.setOnClickListener {
            val loanTermInput = loanTerm.text.toString().trim()

            if (loanTermInput.isEmpty()) {
                AlertDialog.Builder(this)
                    .setTitle("Ошибка")
                    .setMessage("Введите: Срок платежа")
                    .setPositiveButton("ОК", null)
                    .show()
                return@setOnClickListener
            }

            val term = try {
                loanTermInput.toInt()
            } catch (e: NumberFormatException) {
                AlertDialog.Builder(this)
                    .setTitle("Ошибка")
                    .setMessage("Срок должен быть числом")
                    .setPositiveButton("ОК", null)
                    .show()
                return@setOnClickListener
            }


            if (term !in 6..60) {
                AlertDialog.Builder(this)
                    .setTitle("Ошибка")
                    .setMessage("Срок должен быть от 6 до 60 месяцев")
                    .setPositiveButton("ОК", null)
                    .show()
                return@setOnClickListener
            }

            // Расчёт
            val totalPayment = calculateTotalPayment(currentAmount.toDouble(), term)

            // Создаём Intent и передаём ВСЕ данные
            val intent = Intent(this, CalculationActivity::class.java)
            intent.putExtra("TOTAL_PAYMENT", totalPayment)
            intent.putExtra("LOAN_SUM", currentAmount)     // сумма из SeekBar
            intent.putExtra("LOAN_TERM", term)             // срок из EditText

            startActivity(intent)
        }


    }

    // Функция расчёта
    private fun calculateTotalPayment(sum: Double, term: Int): Double {
        val monthlyBase = sum / term
        val firstYearMonths = minOf(term, 12)
        val secondYearMonths = if (term > 12) minOf(term - 12, 12) else 0
        val remainingMonths = if (term > 24) term - 24 else 0

        // Часть 1: Первый год — 5.9%
        val firstYearPayment = firstYearMonths * (monthlyBase + sum * 0.059)

        // Часть 2: Второй год — 5.1%
        val secondYearPayment = if (secondYearMonths > 0) {
            val remainingSum = sum - (monthlyBase * 12)
            secondYearMonths * (monthlyBase + remainingSum * 0.051)
        } else 0.0

        // Часть 3: Остальное — 4.2%
        val remainingPayment = if (remainingMonths > 0) {
            val remainingSum = sum - (monthlyBase * 24)
            remainingMonths * (monthlyBase + remainingSum * 0.042)
        } else 0.0

        return firstYearPayment + secondYearPayment + remainingPayment
    }
}