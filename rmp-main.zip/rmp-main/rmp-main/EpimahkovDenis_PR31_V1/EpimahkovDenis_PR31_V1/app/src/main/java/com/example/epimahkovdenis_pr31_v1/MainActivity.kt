package com.example.epimahkovdenis_pr31_v1

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.SharedMemory
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.log

class MainActivity : AppCompatActivity() {

    // Объявление переменных
    private lateinit var editLogin: EditText
    private lateinit var editPass: EditText
    private lateinit var pref: SharedPreferences
    private lateinit var buttonExit: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Поиск по id
        buttonExit = findViewById(R.id.button_exit)
        editLogin = findViewById(R.id.login_hint)
        editPass = findViewById(R.id.pass_hint)

        pref = getPreferences(MODE_PRIVATE)

        // Обработка нажатия на кнопку
        buttonExit.setOnClickListener {

            val login = editLogin.text.toString().trim()
            val pass = editPass.text.toString().trim()

            if (login.isEmpty() || pass.isEmpty()) {
                AlertDialog.Builder(this)
                    .setTitle("Ошибка")
                    .setMessage("Введите логин и пароль")
                    .setPositiveButton("ОК", null)
                    .show()
                return@setOnClickListener
            }

            val saveLogin = pref.getString("login", null)
            val savePass = pref.getString("pass", null)

            if (saveLogin == null || savePass == null) {
                val editor = pref.edit()
                editor.putString("login", login)
                editor.putString("pass", pass)
                editor.apply()
                Toast.makeText(this, "Логин и пароль сохранены!", Toast.LENGTH_SHORT).show()
            }
            else {
                if (login != saveLogin && pass != savePass) {
                    AlertDialog.Builder(this)
                        .setTitle("Ошибка")
                        .setMessage("Неверный логин или пароль")
                        .setPositiveButton("ОК", null)
                        .show()
                    return@setOnClickListener
                }
            }


            // Переход на второй экран
            val intent = Intent(this, CreditCalActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}