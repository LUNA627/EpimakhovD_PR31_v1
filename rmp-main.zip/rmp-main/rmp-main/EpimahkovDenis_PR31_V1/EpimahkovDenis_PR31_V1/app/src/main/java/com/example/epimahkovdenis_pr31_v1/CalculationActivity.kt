package com.example.epimahkovdenis_pr31_v1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CalculationActivity : AppCompatActivity() {

    // Объявление переменных
    private lateinit var buttonBack: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_calculation)

        // Поиск по id
        buttonBack = findViewById(R.id.button_back)


        // Обработка нажатия на кнопку
        buttonBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }


        // Вывод информации
        val totalPayment = intent.getDoubleExtra("TOTAL_PAYMENT", 0.0)
        findViewById<TextView>(R.id.total_payment_finish).text = "Итог: ${String.format("%.2f", totalPayment)}"

        val loanTerm = intent.getIntExtra("LOAN_TERM", 0)
        findViewById<TextView>(R.id.loan_term_finish).text = "Срок: ${loanTerm}мес."

        val sumCredit = intent.getDoubleExtra("LOAN_SUM", 0.0)
        findViewById<TextView>(R.id.sum_credit_finish).text = "Итог: ${String.format("%.2f", sumCredit)}"

    }
}